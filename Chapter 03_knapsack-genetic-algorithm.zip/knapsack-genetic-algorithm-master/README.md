# knapsack-genetic-algorithm
genetic algorithm that implements knapsack problem solution by reading values and weights from a file while writing errors to log file
